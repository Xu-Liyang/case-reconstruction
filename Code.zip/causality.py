from scipy.spatial import distance
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from statsmodels.tsa.stattools import adfuller, kpss, grangercausalitytests
import pandas as pd
from scipy import stats
from statsmodels.tsa.vector_ar.var_model import VAR
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

class ConvergentCrossMapping(object):
    def __init__(self, X, Y, tau=1, E=2, L=500):
        '''
        X: timeseries for variable X that could be cause by Y
        Y: timeseries for variable Y that could be caused by X
        tau: time lag
        E: shadow manifold embedding dimension
        L: time period/duration to consider (longer = more data)
        We're checking for X -> Y
        '''
        self.X = X
        self.Y = Y
        self.tau = tau
        self.E = E
        self.L = L        
        self.My = self.shadow_manifold(Y)  # shadow manifold for Y (we want to know if info from X is in Y)
        self.t_steps, self.dists = self.get_distances(self.My)  # for distances between points in manifold

    def shadow_manifold(self, X):
        """
        Given
            X: some time series vector
            tau: lag step
            E: shadow manifold embedding dimension
            L: max time step to consider - 1 (starts from 0)
        Returns
            {t:[t, t-tau, t-2*tau ... t-(E-1)*tau]} = Shadow attractor manifold, dictionary of vectors
        """
        X = X[:self.L] # make sure we cut at L
        M = {t:[] for t in range((self.E-1) * self.tau, self.L)}  # shadow manifold
        for t in range((self.E-1) * self.tau, self.L):
            x_lag = [] # lagged values
            for t2 in range(0, self.E-1 + 1): # get lags, we add 1 to E-1 because we want to include E
                x_lag.append(X[t-t2*self.tau])            
            M[t] = x_lag
        return M
    # get pairwise distances between vectors in X
    def get_distances(self, Mx):
        """
        Args
            Mx: The shadow manifold from X
        Returns
            t_steps: timesteps
            dists: n x n matrix showing distances of each vector at t_step (rows) from other vectors (columns)
        """
        # we extract the time indices and vectors from the manifold Mx.
        # we just want to be safe and convert the dictionary to a tuple (time, vector)
        # to preserve the time inds when we separate them
        t_vec = [(k, v) for k,v in Mx.items()]
        t_steps = np.array([i[0] for i in t_vec])
        vecs = np.array([i[1] for i in t_vec])
        dists = distance.cdist(vecs, vecs)    
        return t_steps, dists

    def get_nearest_distances(self, t, t_steps, dists):
        """
        Args:
            t: timestep of vector whose nearest neighbors we want to compute
            t_teps: time steps of all vectors in Mx, output of get_distances()
            dists: distance matrix showing distance of each vector (row) from other vectors (columns). output of get_distances()
            E: embedding dimension of shadow manifold Mx 
        Returns:
            nearest_timesteps: array of timesteps of E+1 vectors that are nearest to vector at time t
            nearest_distances: array of distances corresponding to vectors closest to vector at time t
        """
        t_ind = np.where(t_steps == t) # get the index of time t
        dist_t = dists[t_ind].squeeze() # distances from vector at time t (this is one row)
        # get top closest vectors
        nearest_inds = np.argsort(dist_t)[1:self.E+1+1] # get indices sorted, we exclude 0 which is distance from itself
        nearest_timesteps = t_steps[nearest_inds] # index column-wise, t_steps are same column and row-wise 
        nearest_distances = dist_t[nearest_inds]
        return nearest_timesteps, nearest_distances

    def predict(self, t):
        """
        Args
            t: timestep at Mx to predict Y at same time step
        Returns
            Y_true: the true value of Y at time t
            Y_hat: the predicted value of Y at time t using Mx
        """
        eps = 0.000001 # epsilon minimum distance possible
        nearest_timesteps, nearest_distances = self.get_nearest_distances(t, self.t_steps, self.dists)
        # get weights
        u = np.exp(-nearest_distances/np.max([eps, nearest_distances[0]])) # we divide by the closest distance to scale
        w = u / np.sum(u)
        # get prediction of X
        X_true = self.X[t] # get corresponding true X
        X_cor = np.array(self.X)[nearest_timesteps] # get corresponding Y to cluster in Mx
        X_hat = (w * X_cor).sum() # get X_hat
        return X_true, X_hat

    def causality(self):
        '''
        Args:
            None
        Returns:
            correl: how much self.X causes self.Y. correlation between predicted Y and true Y
        '''
        # run over all timesteps in M
        # X causes Y, we can predict X using My
        # X puts some info into Y that we can use to reverse engineer X from Y        
        X_true_list = []
        X_hat_list = []
        for t in list(self.My.keys()): # for each time step in My
            X_true, X_hat = self.predict(t) # predict X from My
            X_true_list.append(X_true)
            X_hat_list.append(X_hat)
        x, y = X_true_list, X_hat_list
        r, p = pearsonr(x, y)
        return r, p

    def visualize_cross_mapping(self):
        """
        Visualize the shadow manifolds and some cross mappings
        """
        # we want to check cross mapping from Mx to My and My to Mx
        f, axs = plt.subplots(1, 2, figsize=(12, 6))
        for i, ax in zip((0, 1), axs): # i will be used in switching Mx and My in Cross Mapping visualization
            #===============================================
            # Shadow Manifolds Visualization
            X_lag, Y_lag = [], []
            for t in range(1, len(self.X)):
                X_lag.append(self.X[t-self.tau])
                Y_lag.append(self.Y[t-self.tau])
            X_t, Y_t = self.X[1:], self.Y[1:] # remove first value
            ax.scatter(X_t, X_lag, s=5, label='$M_x$')
            ax.scatter(Y_t, Y_lag, s=5, label='$M_y$', c='y')
            #===============================================
            # Cross Mapping Visualization
            A, B = [(self.Y, self.X), (self.X, self.Y)][i]
            cm_direction = ['Mx to My', 'My to Mx'][i]
            Ma = self.shadow_manifold(A)
            Mb = self.shadow_manifold(B)
            t_steps_A, dists_A = self.get_distances(Ma) # for distances between points in manifold

            # Plot cross mapping for different time steps
            timesteps = list(Ma.keys())
            for t in np.random.choice(timesteps, size=3, replace=False):
                near_t_A, near_d_A = self.get_nearest_distances(t, t_steps_A, dists_A)
                for i in range(self.E+1):
                    # points on Ma
                    A_t = Ma[near_t_A[i]][0]
                    A_lag = Ma[near_t_A[i]][1]
                    ax.scatter(A_t, A_lag, c='b', marker='s')

                    # corresponding points on Mb
                    B_t = Mb[near_t_A[i]][0]
                    B_lag = Mb[near_t_A[i]][1]
                    ax.scatter(B_t, B_lag, c='r', marker='*', s=50)  

                    # connections
                    ax.plot([A_t, B_t], [A_lag, B_lag], c='r', linestyle=':') 

            ax.set_title(f'{cm_direction} cross mapping. time lag, tau = {self.tau}, E = {self.E}')
            ax.legend(prop={'size': 14})

            ax.set_xlabel('$X_t$, $Y_t$', size=15)
            ax.set_ylabel('$X_{t-1}$, $Y_{t-1}$', size=15)               
        plt.show()

    def plot_ccm_correls(self):
        """
        Args
            X: X time series
            Y: Y time series
            tau: time lag
            E: shadow manifold embedding dimension
            L: time duration
        Returns
            None. Just correlation plots
        """
        M = self.shadow_manifold(self.Y) # shadow manifold
        t_steps, dists = self.get_distances(M) # for distances

        ccm_XY = ConvergentCrossMapping(self.X, self.Y, self.tau, self.E, self.L) # define new ccm object # Testing for X -> Y
        ccm_YX = ConvergentCrossMapping(self.Y, self.X, self.tau, self.E, self.L) # define new ccm object # Testing for Y -> X

        X_My_true, X_My_pred = [], [] # note pred X | My is equivalent to figuring out if X -> Y
        Y_Mx_true, Y_Mx_pred = [], [] # note pred Y | Mx is equivalent to figuring out if Y -> X

        for t in range(self.tau, self.L):
            true, pred = ccm_XY.predict(t)
            X_My_true.append(true)
            X_My_pred.append(pred)

            true, pred = ccm_YX.predict(t)
            Y_Mx_true.append(true)
            Y_Mx_pred.append(pred)

            # # plot
        figs, axs = plt.subplots(1, 2, figsize=(12, 5))

        # predicting X from My
        r, p = np.round(pearsonr(X_My_true, X_My_pred), 4)

        axs[0].scatter(X_My_true, X_My_pred, s=10)
        axs[0].set_xlabel('$X(t)$ (observed)', size=12)
        axs[0].set_ylabel('$\hat{X}(t)|M_y$ (estimated)', size=12)
        axs[0].set_title(f'tau={self.tau}, E={self.E}, L={self.L}\n'
                         f'X->Y Correlation coeff={np.round(r, 2)}, p={np.round(p, 2)}')

        # predicting Y from Mx
        r, p = np.round(pearsonr(Y_Mx_true, Y_Mx_pred), 4)

        axs[1].scatter(Y_Mx_true, Y_Mx_pred, s=10)
        axs[1].set_xlabel('$Y(t)$ (observed)', size=12)
        axs[1].set_ylabel('$\hat{Y}(t)|M_x$ (estimated)', size=12)
        axs[1].set_title(f'tau={self.tau}, E={self.E}, L={self.L}\n'
                         f'Y->X Correlation coeff={np.round(r, 2)}, p={np.round(p, 2)}')
        plt.show()

    def plot_convergence(self):

        L_range = range(50, self.L, 20)

        Xhat_My, Yhat_Mx = [], [] # correlation list
        for L in L_range:
            ccm_XY = ConvergentCrossMapping(self.X, self.Y, self.tau, self.E, L) # define new ccm object # Testing for X -> Y
            ccm_YX = ConvergentCrossMapping(self.Y, self.X, self.tau, self.E, L) # define new ccm object # Testing for Y -> X
            Xhat_My.append(ccm_XY.causality()[0])
            Yhat_Mx.append(ccm_YX.causality()[0])

        # plot convergence as L->inf. Convergence is necessary to conclude causality
        plt.figure(figsize=(5,5))
        plt.plot(L_range, Xhat_My, label='$\hat{X}(t)|M_y$')
        plt.plot(L_range, Yhat_Mx, label='$\hat{Y}(t)|M_x$')
        plt.xlabel('L', size=12)
        plt.ylabel('correl', size=12)
        plt.legend(prop={'size': 16})
#         print("Tips: p < 0.05, implies the x does not cause y can be rejected")
        print('X->Y r', np.round(Xhat_My[-1], 2), 'p value', np.round(ccm_XY.causality()[1], 2))
        print('Y->X r', np.round(Yhat_Mx[-1], 2), 'p value', np.round(ccm_YX.causality()[1], 2))


class GrangerCausality(object):
    def __init__(self, data, maxlag, test='ssr_chi2test', verbose=False):
        """Check Granger Causality of all possible combinations of the time series.
        The rows are the response variables, columns are predictors. The values in the table
        are the P-Values. P-Values lesser than the significance level (0.05), implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.

        data      : pandas dataframe containing the time series variables
        variables : list containing names of the time series variables.
        maxlag         : {int, Iterable[int]}, If an integer, computes the test for all lags up to maxlag. If an iterable, computes the tests only for the lags in maxlag.
        """
        self.data = data
        self.variables = data.columns
        self.maxlag = maxlag
        self.test = test
        self.verbose = verbose

    def granger_causation_matrix(self):
        df = pd.DataFrame(np.zeros((len(self.variables), len(self.variables))), columns=self.variables, index=self.variables)
        for c in df.columns:
            for r in df.index:
                test_result = grangercausalitytests(self.data[[r, c]], self.maxlag, verbose=self.verbose)
                p_values = [round(test_result[i+1][0][self.test][1],4) for i in range(self.maxlag)]
                if self.verbose: print(f'Y = {r}, X = {c}, P Values = {p_values}')
                min_p_value = np.min(p_values)
                df.loc[r, c] = min_p_value
        df.columns = [var + '_x' for var in self.variables]
        df.index = [var + '_y' for var in self.variables]
#         print("Tips: p<0.05, implies the x does not cause y can be rejected")
        return df


class StationaryTest(object):
    def __init__(self, data):
        """data      : pandas dataframe containing the time series variables"""
        self.data = data

    def kpss_test(self):
        test_stat, p_val = [], []
        cv_1pct, cv_2p5pct, cv_5pct, cv_10pct = [], [], [], []
        for c in self.data.columns:
            kpss_res = kpss(self.data[c].dropna(), regression='ct')
            test_stat.append(kpss_res[0])
            p_val.append(kpss_res[1])
            cv_1pct.append(kpss_res[3]['1%'])
            cv_2p5pct.append(kpss_res[3]['2.5%'])
            cv_5pct.append(kpss_res[3]['5%'])
            cv_10pct.append(kpss_res[3]['10%'])
        kpss_res_df = pd.DataFrame({'Test statistic': test_stat,
                                   'p-value': p_val,
                                   'Critical value - 1%': cv_1pct,
                                   'Critical value - 2.5%': cv_2p5pct,
                                   'Critical value - 5%': cv_5pct,
                                   'Critical value - 10%': cv_10pct},
                                 index=self.data.columns).T
        kpss_res_df = kpss_res_df.round(4)
#         print("Tips: p < 0.05 or Test statistic > Critical value, implies trend is stationary can be rejected")
        return kpss_res_df

    def adf_test(self):
        test_stat, p_val = [], []
        cv_1pct, cv_5pct, cv_10pct = [], [], []
        for c in self.data.columns:
            adf_res = adfuller(self.data[c].dropna())
            test_stat.append(adf_res[0])
            p_val.append(adf_res[1])
            cv_1pct.append(adf_res[4]['1%'])
            cv_5pct.append(adf_res[4]['5%'])
            cv_10pct.append(adf_res[4]['10%'])
        adf_res_df = pd.DataFrame({'Test statistic': test_stat,
                                   'p-value': p_val,
                                   'Critical value - 1%': cv_1pct,
                                   'Critical value - 5%': cv_5pct,
                                   'Critical value - 10%': cv_10pct},
                                 index=self.data.columns).T
        adf_res_df = adf_res_df.round(4)
#         print("Tips: p > 0.05 or Test statistic > Critical value, implies trend is stationary can be rejected")
        return adf_res_df


def select_lag(data):
    aic, bic, fpe, hqic = [], [], [], []
    model = VAR(data)
    lag = np.arange(1,60)
    for i in lag:
        result = model.fit(i)
        aic.append(result.aic)
        bic.append(result.bic)
        fpe.append(result.fpe)
        hqic.append(result.hqic)
    lags_metrics_df = pd.DataFrame({'AIC': aic,
                                    'BIC': bic,
                                    'HQIC': hqic,
                                    'FPE': fpe},
                                   index=lag)
    fig, ax = plt.subplots(1, 4, figsize=(15, 3), sharex=True)
    lags_metrics_df.plot(subplots=True, ax=ax, marker='o')
    plt.tight_layout()
    print(lags_metrics_df.idxmin(axis=0))


class TransferEntropy(object):
    def __init__(self):
        pass

    def joint_probability(self, data, bins=20):
        """
        measure the joint probability of the given multi-dimension data
        Parameters
        ----------
        data: multi-dimension data, shape=(n,m) n is the # samples, m is the # variables
        bins: optional (default=20)
            bin size of the histogram
        Returns
        -------
        calculated joint probability/probability: float
        """
        hist, edges = np.histogramdd(data, bins)
        # convert bins counts to probability values
        joint_p = hist / float(np.sum(hist))
        return joint_p

    def mi(self, *x, bins=20):
        """
        measure the conditional mutual information of the given multi-dimension x, y, z
        Parameters
        ----------
        x:
        bins: optional (default=20)
            bin size of the histogram
        Returns
        -------
        calculated conditional mutual information: float
        """
        data = [item.reshape(-1,1) for item in x]
        hist, _ = np.histogramdd(np.hstack(data), bins)
        # convert bins counts to probability values
        p = hist / float(np.sum(hist))
        # now we can do the calculation using the pxy, px_py 2D arrays
        nonzeros = p > 0  # filer out the zero values
        mi = -np.sum(p[nonzeros] * np.log(p[nonzeros]))
        return mi

    def te_xy(self, y, x, k=1, l=1):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        jj = abs(k - l)

        x_ = x
        y_ = y
        if k == l:
            pass
        elif k > l:
            x_ = x_[jj:]
        elif k < l:
            y_ = y_[jj:]
        y_t = y_[k:]

        y_hat = []
        for i in range(1, k + 1):
            y_hat.append(y_[k - i:-i])

        x_hat = []
        for j in range(1, l + 1):
            x_hat.append(x_[l - j:-j])


        te = self.mi(y_t,*y_hat) - self.mi(*y_hat) - self.mi(y_t, *y_hat, *x_hat) + self.mi(*y_hat, *x_hat)

        tes = []
        for i in range(1000):
            x_fake = stats.norm.rvs(size=np.array(y_hat).shape)
            tes.append(self.mi(y_t, *y_hat) - self.mi(*y_hat) - self.mi(y_t, *y_hat, *x_fake) + self.mi(*y_hat, *x_fake))

        mean = np.array(tes).mean()
        std = np.array(tes).std()
        p_value = round(stats.norm.sf((te - mean) / std), 4)
        cv_001 = round(stats.norm.isf(0.01)*std+mean, 4)
        cv_005 = round(stats.norm.isf(0.05)*std+mean, 4)
        cv_010 = round(stats.norm.isf(0.10)*std+mean, 4)
#         print("Tips: p < 0.05 or TE > Critical value, implies the X does not cause Y can be rejected according to Z-test")

        return {"TE(X->Y)": round(te, 4),
                "p_value": p_value,
                "CriticalValue(0.01)":cv_001,
                "CriticalValue(0.05)":cv_005,
                "CriticalValue(0.10)":cv_010}

    def te_xy_with_lag(self, y, x, k=1, l=1, lag_x=0):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x != 0:
            y = y[lag_x:]
            x = x[:-lag_x]

        jj = abs(k - l)

        x_ = x
        y_ = y
        if k == l:
            pass
        elif k > l:
            x_ = x_[jj:]
        elif k < l:
            y_ = y_[jj:]
        y_t = y_[k:]

        y_hat = []
        for i in range(1, k + 1):
            y_hat.append(y_[k - i:-i])

        x_hat = []
        for j in range(1, l + 1):
            x_hat.append(x_[l - j:-j])


        te = self.mi(y_t,*y_hat) - self.mi(*y_hat) - self.mi(y_t, *y_hat, *x_hat) + self.mi(*y_hat, *x_hat)

        tes = []
        for i in range(1000):
            x_fake = stats.norm.rvs(size=np.array(y_hat).shape)
            tes.append(self.mi(y_t, *y_hat) - self.mi(*y_hat) - self.mi(y_t, *y_hat, *x_fake) + self.mi(*y_hat, *x_fake))

        mean = np.array(tes).mean()
        std = np.array(tes).std()
        p_value = round(stats.norm.sf((te - mean) / std), 4)
        cv_001 = round(stats.norm.isf(0.01)*std+mean, 4)
        cv_005 = round(stats.norm.isf(0.05)*std+mean, 4)
        cv_010 = round(stats.norm.isf(0.10)*std+mean, 4)
#         print("Tips: p < 0.05 or TE > Critical value, implies the X does not cause Y can be rejected according to Z-test")

        return {"TE(X->Y)": round(te, 4),
                "p_value": p_value,
                "CriticalValue(0.01)":cv_001,
                "CriticalValue(0.05)":cv_005,
                "CriticalValue(0.10)":cv_010}

    def mi_with_lag(self, y, x, lag_x=1):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x != 0:
            y_t = y[lag_x:]
            x_t = x[:-lag_x]

        res = self.mi(y_t)+self.mi(x_t)-self.mi(y_t, x_t)

        return {"MI(X<->Y)": round(res, 4)}

    def cmi_with_lag(self, y, x, z, lag_x=1, lag_z=1):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x!=0 and lag_z!=0:
            lag_gap = abs(lag_x - lag_z)
            lag_max = max(lag_x, lag_z)
            lag_x_s = 0 if lag_x > lag_z else lag_gap
            lag_z_s = 0 if lag_x < lag_z else lag_gap
            if lag_x == 0:
                y = y[lag_max:]
                x = x[lag_max:]
                z = z[lag_z_s:-lag_z]
            elif lag_z == 0:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_max:]
            else:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_z_s:-lag_z]


        res = self.mi(y, z) + self.mi(x, z) - self.mi(y, x, z) - self.mi(z)

        ctes = []
        for i in range(10000):
            z_fake = stats.norm.rvs(size=np.array(z).shape)
            ctes.append(self.mi(y, z_fake) + self.mi(x, z_fake) - self.mi(y, x, z_fake) - self.mi(z_fake))

        mean = np.array(ctes).mean()
        std = np.array(ctes).std()
        p_value = round(stats.norm.sf((res - mean) / std), 4)
        cv_001 = round(stats.norm.isf(0.01)*std+mean, 4)
        cv_005 = round(stats.norm.isf(0.05)*std+mean, 4)
        cv_010 = round(stats.norm.isf(0.10)*std+mean, 4)

        return {"CMI(X<->Y|Z)": round(res, 4),
                "p_value": p_value,
                "CriticalValue(0.01)":cv_001,
                "CriticalValue(0.05)":cv_005,
                "CriticalValue(0.10)":cv_010}
    
    def cmi_with_lag_sigma(self, y, x, z, lag_x=1, lag_z=1):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x!=0 and lag_z!=0:
            lag_gap = abs(lag_x - lag_z)
            lag_max = max(lag_x, lag_z)
            lag_x_s = 0 if lag_x > lag_z else lag_gap
            lag_z_s = 0 if lag_x < lag_z else lag_gap
            if lag_x == 0:
                y = y[lag_max:]
                x = x[lag_max:]
                z = z[lag_z_s:-lag_z]
            elif lag_z == 0:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_max:]
            else:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_z_s:-lag_z]

        res = self.mi(y, z) + self.mi(x, z) - self.mi(y, x, z) - self.mi(z)
        return round(res, 4)
    

    def te_xy_with_lag_sigma(self, y, x, k=1, l=1, lag_x=0):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x != 0:
            y = y[lag_x:]
            x = x[:-lag_x]

        jj = abs(k - l)

        x_ = x
        y_ = y
        if k == l:
            pass
        elif k > l:
            x_ = x_[jj:]
        elif k < l:
            y_ = y_[jj:]
        y_t = y_[k:]

        y_hat = []
        for i in range(1, k + 1):
            y_hat.append(y_[k - i:-i])

        x_hat = []
        for j in range(1, l + 1):
            x_hat.append(x_[l - j:-j])

        te = self.mi(y_t,*y_hat) - self.mi(*y_hat) - self.mi(y_t, *y_hat, *x_hat) + self.mi(*y_hat, *x_hat)

        return round(te, 4)

    def cte_xyz(self, y, x, z, k=1, l=1, d=1):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        j1 = abs(k - l)
        j2 = abs(k - d)
        j3 = abs(d - l)

        x_ = x
        y_ = y
        z_ = z
        if k == l and k == d:
            pass
        elif max(k, l, d) == k:
            x_ = x_[j1:]
            z_ = z_[j2:]
        elif max(k, l, d) == l:
            y_ = y_[j1:]
            z_ = z_[j3:]
        elif max(k, l, d) == d:
            y_ = y_[j2:]
            x_ = x_[j3:]

        y_t = y_[k:]

        y_hat = []
        for i in range(1, k + 1):
            y_hat.append(y_[k - i:-i])

        x_hat = []
        for i in range(1, l + 1):
            x_hat.append(x_[l - i:-i])

        z_hat = []
        for i in range(1, d + 1):
            z_hat.append(z_[d - i:-i])


        cte = self.mi(y_t, *y_hat, *z_hat) - self.mi(*y_hat, *z_hat) - self.mi(y_t, *y_hat, *x_hat, *z_hat) + self.mi(*y_hat, *x_hat, *z_hat)

        ctes = []
        for i in range(10000):
            z_fake = stats.norm.rvs(size=np.array(z_hat).shape)
            ctes.append(self.mi(y_t, *y_hat, *z_fake) - self.mi(*y_hat, *z_fake) - self.mi(y_t, *y_hat, *x_hat, *z_fake) + self.mi(*y_hat, *x_hat, *z_fake))

        mean = np.array(ctes).mean()
        std = np.array(ctes).std()
        p_value = round(stats.norm.sf((cte - mean) / std), 4)
        cv_001 = round(stats.norm.isf(0.01)*std+mean, 4)
        cv_005 = round(stats.norm.isf(0.05)*std+mean, 4)
        cv_010 = round(stats.norm.isf(0.10)*std+mean, 4)
#         print("Tips: p < 0.05 or CTE > Critical value, implies the X does not cause Y given Z can be rejected according to Z-test")

        return {"CTE(X->Y|Z)": round(cte, 4),
                "p_value": p_value,
                "CriticalValue(0.01)":cv_001,
                "CriticalValue(0.05)":cv_005,
                "CriticalValue(0.10)":cv_010}

    def cte_xyz_with_lag(self, y, x, z, k=1, l=1, d=1, lag_x=0, lag_z=0):
        """
        Check Transfer Entropy Causality of the time series.
        te-Values lesser than the significance level, implies
        the Null Hypothesis that the coefficients of the corresponding past values is
        zero, that is, the X does not cause Y can be rejected.
        """
        if lag_x!=0 and lag_z!=0:
            lag_gap = abs(lag_x - lag_z)
            lag_max = max(lag_x, lag_z)
            lag_x_s = 0 if lag_x > lag_z else lag_gap
            lag_z_s = 0 if lag_x < lag_z else lag_gap
            if lag_x == 0:
                y = y[lag_max:]
                x = x[lag_max:]
                z = z[lag_z_s:-lag_z]
            elif lag_z == 0:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_max:]
            else:
                y = y[lag_max:]
                x = x[lag_x_s:-lag_x]
                z = z[lag_z_s:-lag_z]

        j1 = abs(k - l)
        j2 = abs(k - d)
        j3 = abs(d - l)

        x_ = x
        y_ = y
        z_ = z
        if k == l and k == d:
            pass
        elif max(k, l, d) == k:
            x_ = x_[j1:]
            z_ = z_[j2:]
        elif max(k, l, d) == l:
            y_ = y_[j1:]
            z_ = z_[j3:]
        elif max(k, l, d) == d:
            y_ = y_[j2:]
            x_ = x_[j3:]

        y_t = y_[k:]

        y_hat = []
        for i in range(1, k + 1):
            y_hat.append(y_[k - i:-i])

        x_hat = []
        for i in range(1, l + 1):
            x_hat.append(x_[l - i:-i])

        z_hat = []
        for i in range(1, d + 1):
            z_hat.append(z_[d - i:-i])


        cte = self.mi(y_t, *y_hat, *z_hat) - self.mi(*y_hat, *z_hat) - self.mi(y_t, *y_hat, *x_hat, *z_hat) + self.mi(*y_hat, *x_hat, *z_hat)

        ctes = []
        for i in range(10000):
            z_fake = stats.norm.rvs(size=np.array(z_hat).shape)
            ctes.append(self.mi(y_t, *y_hat, *z_fake) - self.mi(*y_hat, *z_fake) - self.mi(y_t, *y_hat, *x_hat, *z_fake) + self.mi(*y_hat, *x_hat, *z_fake))

        mean = np.array(ctes).mean()
        std = np.array(ctes).std()
        p_value = round(stats.norm.sf((cte - mean) / std), 4)
        cv_001 = round(stats.norm.isf(0.01)*std+mean, 4)
        cv_005 = round(stats.norm.isf(0.05)*std+mean, 4)
        cv_010 = round(stats.norm.isf(0.10)*std+mean, 4)
#         print("Tips: p < 0.05 or CTE > Critical value, implies the X does not cause Y given Z can be rejected according to Z-test")

        return {"CTE(X->Y|Z)": round(cte, 4),
                "p_value": p_value,
                "CriticalValue(0.01)":cv_001,
                "CriticalValue(0.05)":cv_005,
                "CriticalValue(0.10)":cv_010}

    def cmi(self, x, y, z, bins=20):
        """
        measure the conditional mutual information of the given multi-dimension x, y, z
        Parameters
        ----------
        x:
        y:
        z: conditional
        bins: optional (default=20)
            bin size of the histogram
        Returns
        -------
        calculated conditional mutual information: float
        """
        hist_xyz, _ = np.histogramdd(np.hstack((x.reshape(-1, 1), y.reshape(-1, 1), z.reshape(-1, 1))), bins)
        # convert bins counts to probability values
        pxyz = hist_xyz / float(np.sum(hist_xyz))
        hist_xz, _ = np.histogramdd(np.hstack((x.reshape(-1, 1), z.reshape(-1, 1))), bins)
        # convert bins counts to probability values
        pxz = hist_xz / float(np.sum(hist_xz))
        hist_yz, _ = np.histogramdd(np.hstack((y.reshape(-1, 1), z.reshape(-1, 1))), bins)
        # convert bins counts to probability values
        pyz = hist_yz / float(np.sum(hist_yz))
        hist_z, _ = np.histogramdd(np.hstack((z.reshape(-1, 1))), bins)
        # convert bins counts to probability values
        pz = hist_z / float(np.sum(hist_z))
        pxz_pyz = pxz[:, None] * pyz[None, :]  # broadcast to multiply marginals
        pxyz_pz = pxyz * pz
        # now we can do the calculation using the pxy, px_py 2D arrays
        nonzeros = pxyz > 0  # filer out the zero values
        cmi = np.sum(pxyz[nonzeros] * np.log(pxyz_pz[nonzeros] / pxz_pyz[nonzeros]))
        return cmi
